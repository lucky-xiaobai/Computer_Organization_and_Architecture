This interface IP  debounces input typically coming from a push-button. 
