This interface IP provides serial communication using 100 MHz input clock. 
It supports 9600, 19200, 38400, 57600, and 115200 baud rates
