This interface IP generates timing signals (HSYNC, VSYNC, and Video Valid) along with horizontal and vertical pixel position. 
It supports VGA, SVGA, XVGA, and SXGA video standards compatible monitors having 60 Hz refresh rate.
